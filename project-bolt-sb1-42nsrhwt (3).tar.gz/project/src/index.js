import dotenv from 'dotenv';
import TelegramBot from 'node-telegram-bot-api';
import winston from 'winston';
import { AvitoParser } from './parser.js';

dotenv.config();

const VERSION = '2.0.2';

// Configure logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} ${level}: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'parser.log' })
  ]
});

// Initialize Telegram bot if credentials are provided
let bot = null;
if (process.env.TELEGRAM_TOKEN && process.env.TELEGRAM_CHAT_ID) {
  bot = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: false });
  logger.info('Telegram bot initialized');
}

async function main() {
  const parser = new AvitoParser({
    maxPages: process.env.MAX_PAGES || 1,
    keywords: process.env.KEYWORDS ? process.env.KEYWORDS.split(',') : [],
    maxPrice: process.env.MAX_PRICE ? parseInt(process.env.MAX_PRICE) : Infinity,
    minPrice: process.env.MIN_PRICE ? parseInt(process.env.MIN_PRICE) : 0,
    location: process.env.LOCATION || '',
    proxy: process.env.PROXY || '',
    debug: process.env.DEBUG === 'true'
  });

  try {
    logger.info('Starting Avito parser...');
    const results = await parser.parse();
    
    // Send results to Telegram if configured
    if (bot && process.env.TELEGRAM_CHAT_ID) {
      const chatIds = process.env.TELEGRAM_CHAT_ID.split(',');
      for (const chatId of chatIds) {
        await bot.sendMessage(chatId.trim(), 
          `Found ${results.length} items matching your criteria.\n\n` +
          results.map(item => 
            `${item.title}\nPrice: ${item.price}\nLink: ${item.url}`
          ).join('\n\n')
        );
      }
    }

    logger.info(`Parsing completed. Found ${results.length} items.`);
  } catch (error) {
    logger.error('Error during parsing:', error);
  }
}

main().catch(console.error);