import axios from 'axios';
import * as cheerio from 'cheerio';

export class AvitoParser {
  constructor(config) {
    this.config = {
      maxPages: config.maxPages || 1,
      keywords: config.keywords || [],
      maxPrice: config.maxPrice || Infinity,
      minPrice: config.minPrice || 0,
      location: config.location || '',
      proxy: config.proxy || '',
      debug: config.debug || false
    };

    this.axiosConfig = {};
    if (this.config.proxy) {
      this.axiosConfig.proxy = {
        host: this.config.proxy.split('@')[1].split(':')[0],
        port: parseInt(this.config.proxy.split('@')[1].split(':')[1]),
        auth: {
          username: this.config.proxy.split('@')[0].split(':')[0],
          password: this.config.proxy.split('@')[0].split(':')[1]
        }
      };
    }
  }

  async parse() {
    const results = [];
    
    try {
      for (let page = 1; page <= this.config.maxPages; page++) {
        const pageUrl = this.buildUrl(page);
        const items = await this.parsePage(pageUrl);
        results.push(...items);
        
        // Add delay between requests to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    } catch (error) {
      console.error('Error during parsing:', error);
      throw error;
    }

    return this.filterResults(results);
  }

  buildUrl(page) {
    // Implement URL building logic based on configuration
    let url = 'https://www.avito.ru/all';
    if (this.config.location) {
      url += `/${this.config.location}`;
    }
    if (page > 1) {
      url += `?p=${page}`;
    }
    return url;
  }

  async parsePage(url) {
    const response = await axios.get(url, this.axiosConfig);
    const $ = cheerio.load(response.data);
    const items = [];

    // Implement parsing logic here based on Avito's HTML structure
    $('.item').each((_, element) => {
      const item = {
        title: $(element).find('.title').text().trim(),
        price: this.parsePrice($(element).find('.price').text()),
        url: $(element).find('a').attr('href'),
        // Add more fields as needed
      };
      items.push(item);
    });

    return items;
  }

  parsePrice(priceStr) {
    return parseInt(priceStr.replace(/[^\d]/g, '')) || 0;
  }

  filterResults(items) {
    return items.filter(item => {
      const priceInRange = item.price >= this.config.minPrice && 
                          item.price <= this.config.maxPrice;
      
      const matchesKeywords = this.config.keywords.length === 0 || 
                             this.config.keywords.some(keyword => 
                               item.title.toLowerCase().includes(keyword.toLowerCase())
                             );

      return priceInRange && matchesKeywords;
    });
  }
}